package com.example.movieapp.product_module


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import coil.compose.rememberImagePainter
import com.example.movieapp.R


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductScaffold(vm: ProductViewModel) {
    LaunchedEffect(Unit) {
        vm.getProductList() // Call getProductList() inside a coroutine scope
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Product Screen") },
                actions = {
                    IconButton(onClick = {
                        // Optionally, you can call getProductList() directly here as well
                        // vm.getProductList()
                    }) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            ProductBody(vm)
        }
    }
}


@Composable
fun ProductBody(vm: ProductViewModel) {
    when {
        vm.isLoading -> {
            CircularProgressIndicator()
        }
        vm.errorMessage.isNotEmpty() -> {
            Text(vm.errorMessage)
        }
        else -> {
            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                items(vm.productList.size) {
                    ProductItem(vm.productList[it])
                }
            }
        }
    }
}
@Composable
fun ProductItem(item: Product) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(5.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Surface(
            modifier = Modifier
                .size(120.dp)
                .background(Color.Gray)
        ) {
            val imageUrl = "${PRODUCT_BASE_URL}${item.image}"  // Assuming PRODUCT_BASE_URL is correctly defined
            val painter = rememberImagePainter(
                data = imageUrl,
                builder = {
                    crossfade(true)  // Enable crossfade animation

                }
            )
            Image(
                painter = painter,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
            )
        }
        Column(modifier = Modifier.padding(10.dp)) {
            Text(text = item.title)
            Text(text = "$" + item.price)
            Text(text = item.category)
        }
    }
}
